import React, { Component } from 'react';
import './App.css';
import Layout from '../src/Containers/Layout'

class App extends Component {
  render() {
    return (
      <div className="App">
        <Layout/>
      </div>
    );
  }
}

export default App;
