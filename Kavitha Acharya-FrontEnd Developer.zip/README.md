﻿Author: Kavitha Acharya

This project is built with React.js,HTML5,CSS3 and Axios to call teh API.

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## steps to execute it

1. Extract all files from zip folder.
2. open the 'src' folder using any code editor like Visual Studio/Atom/ Sublime
3. install node.js and npm/yarn
4. type 'npm-install'--> this will install all the packages from package.json.
5. npm start ---> this will automatically start a new tab in your web browser and you can execute the code on http://localhost:3000/






